PROJECTION INFORMATION

The data is in the Web Mercator projection and uses the WGS84 datum.
